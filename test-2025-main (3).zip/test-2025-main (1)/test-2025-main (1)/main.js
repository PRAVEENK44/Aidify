import { GoogleGenerativeAI, HarmBlockThreshold, HarmCategory } from "@google/generative-ai"
import MarkdownIt from "markdown-it"
import { maybeShowApiKeyBanner } from "./gemini-api-banner"
import { retrieveRelevantInformation, formatRetrievedInformation } from "./rag-utils.js"
import "./style.css"

// Initialize markdown parser
const md = new MarkdownIt()

// First aid instruction prompt template
const FIRST_AID_PROMPT = `Analyze this image and provide detailed step-by-step first aid instructions for the injury or medical situation shown. If you can identify a specific injury, condition, or emergency situation:

1. Identify what medical condition or injury is shown in the image
2. Determine the severity (Mild, Moderate, Severe)
3. Estimate treatment time required
4. List the step-by-step first aid procedures that should be followed
5. Mention any important warnings or precautions
6. Indicate when professional medical help should be sought

Format your response with clear sections for:
- Injury type and severity
- Emergency warning (if applicable)
- Estimated treatment time
- Numbered steps with clear instructions
- Medical disclaimer

If no clear medical emergency is visible in the image, please state that and provide general first aid guidance instead.`

// API Key
const API_KEY = "AIzaSyD7rh9QUdC_btRlx9emR78Y7-EWlhH4nMw"

// DOM Elements
const uploadForm = document.getElementById("upload-form")
const fileInput = document.getElementById("fileInput")
const dropzone = document.getElementById("dropzone")
const browseLink = document.querySelector(".browse-link")
const analyzeButton = document.querySelector(".btn-analyze")
const output = document.querySelector(".output")
const ragToggle = document.getElementById("ragToggle")

// State
let useRag = true // Default to using RAG

// Event Listeners
document.addEventListener("DOMContentLoaded", () => {
  // Initialize UI components
  initializeDropzone()
  initializeNavigation()
  initializeEmergencyButton()
  initializeChatButton()
})

// Initialize dropzone functionality
function initializeDropzone() {
  // File input change event
  fileInput.addEventListener("change", (e) => {
    if (fileInput.files.length > 0) {
      const file = fileInput.files[0]
      updateDropzoneWithFile(file)
      analyzeButton.disabled = false
    }
  })

  // Dropzone click event
  dropzone.addEventListener("click", () => {
    fileInput.click()
  })

  // Browse link click event
  browseLink.addEventListener("click", (e) => {
    e.stopPropagation()
    fileInput.click()
  })

  // Drag and drop events
  dropzone.addEventListener("dragover", (e) => {
    e.preventDefault()
    dropzone.classList.add("dragover")
  })

  dropzone.addEventListener("dragleave", () => {
    dropzone.classList.remove("dragover")
  })

  dropzone.addEventListener("drop", (e) => {
    e.preventDefault()
    dropzone.classList.remove("dragover")

    if (e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0]
      fileInput.files = e.dataTransfer.files
      updateDropzoneWithFile(file)
      analyzeButton.disabled = false
    }
  })

  // RAG toggle event
  ragToggle.addEventListener("change", function () {
    useRag = this.checked
    console.log("RAG mode:", useRag ? "enabled" : "disabled")
  })
}

// Update dropzone UI when file is selected
function updateDropzoneWithFile(file) {
  // Validate file type
  const validTypes = ["image/jpeg", "image/jpg", "image/png"]
  if (!validTypes.includes(file.type)) {
    alert("Please select a valid image file (PNG, JPG, JPEG)")
    return
  }

  // Validate file size (5MB max)
  if (file.size > 5 * 1024 * 1024) {
    alert("File size exceeds 5MB limit")
    return
  }

  // Update dropzone UI
  const reader = new FileReader()
  reader.onload = (e) => {
    dropzone.innerHTML = `
      <img src="${e.target.result}" alt="Uploaded injury" style="max-height: 200px; max-width: 100%;">
      <p>${file.name} (${formatFileSize(file.size)})</p>
      <p class="file-types">Click to change image</p>
    `
  }
  reader.readAsDataURL(file)
}

// Format file size in KB or MB
function formatFileSize(bytes) {
  if (bytes < 1024 * 1024) {
    return (bytes / 1024).toFixed(1) + " KB"
  } else {
    return (bytes / (1024 * 1024)).toFixed(1) + " MB"
  }
}

// Initialize navigation functionality
function initializeNavigation() {
  const navLinks = document.querySelectorAll("nav a")

  navLinks.forEach((link) => {
    link.addEventListener("click", function (e) {
      // Remove active class from all links
      navLinks.forEach((l) => l.classList.remove("active"))
      // Add active class to clicked link
      this.classList.add("active")
    })
  })
}

// Initialize emergency button functionality
function initializeEmergencyButton() {
  const emergencyButtons = document.querySelectorAll(
    ".btn-emergency, .emergency-call-button, .btn-emergency-call, .emergency-link",
  )

  emergencyButtons.forEach((button) => {
    button.addEventListener("click", (e) => {
      if (!confirm("This will dial emergency services. Do you want to continue?")) {
        e.preventDefault()
      }
    })
  })
}

// Initialize chat button functionality
function initializeChatButton() {
  const chatButton = document.querySelector(".chat-toggle")

  chatButton.addEventListener("click", () => {
    alert("Medical chat feature will be available soon!")
  })
}

// Form submission handler
uploadForm.addEventListener("submit", async (ev) => {
  ev.preventDefault()

  if (!fileInput.files[0]) {
    alert("Please select an image file first")
    return
  }

  // Show loading state
  analyzeButton.disabled = true
  analyzeButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Analyzing...'
  output.innerHTML =
    '<div class="loading"><i class="fas fa-spinner fa-spin"></i><p>Analyzing image and generating first aid instructions...</p></div>'

  try {
    await analyzeInjuryImage()
  } catch (error) {
    output.innerHTML = `<div class="error"><i class="fas fa-exclamation-circle"></i><p>Error: ${error.message}</p></div>`
    console.error(error)
  } finally {
    // Reset button state
    analyzeButton.disabled = false
    analyzeButton.innerHTML = "Analyze Injury"
  }
})

// Analyze injury image and generate first aid instructions
async function analyzeInjuryImage() {
  // Create a container for showing RAG information
  const ragInfoContainer = document.createElement("div")
  ragInfoContainer.className = "rag-info"
  ragInfoContainer.style.display = "none"
  output.appendChild(ragInfoContainer)

  // Load the image as a base64 string
  const file = fileInput.files[0]
  const imageBase64 = await new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.readAsDataURL(file)
    reader.onload = () => {
      const base64String = reader.result.split(",")[1] // Extract base64 part
      resolve(base64String)
    }
    reader.onerror = reject
  })

  // Determine whether to use RAG based on toggle state
  let finalPrompt = FIRST_AID_PROMPT
  let relevantInfo = []

  if (useRag) {
    // RAG Enhancement: Retrieve relevant information from knowledge base
    relevantInfo = retrieveRelevantInformation(FIRST_AID_PROMPT, 2)
    const contextInfo = formatRetrievedInformation(relevantInfo)

    // Add the retrieved information to the prompt
    finalPrompt = FIRST_AID_PROMPT + contextInfo

    // Display retrieval information to user
    output.innerHTML =
      '<div class="loading"><i class="fas fa-spinner fa-spin"></i>' +
      "<p>Analyzing image...</p>" +
      "<p>Retrieved relevant information from knowledge base</p>" +
      "<p>Generating enhanced first aid instructions...</p></div>"

    // Update the RAG info container to show which knowledge base entries were retrieved
    ragInfoContainer.style.display = "block"
    ragInfoContainer.innerHTML =
      "<h3>RAG Knowledge Base Entries Retrieved:</h3><ul>" +
      relevantInfo
        .map((info) => `<li><strong>${info.title}</strong> (Relevance: ${Math.round(info.similarity * 100)}%)</li>`)
        .join("") +
      "</ul><p><small>Using Retrieval-Augmented Generation (RAG) to enhance AI responses with relevant first aid knowledge.</small></p>"
  } else {
    // Standard mode without RAG
    output.innerHTML =
      '<div class="loading"><i class="fas fa-spinner fa-spin"></i>' +
      "<p>Analyzing image...</p>" +
      "<p>Generating first aid instructions...</p></div>"
    ragInfoContainer.style.display = "none"
  }

  // Assemble the prompt by combining the text with the chosen image
  const contents = [
    {
      role: "user",
      parts: [{ inline_data: { mime_type: "image/jpeg", data: imageBase64 } }, { text: finalPrompt }],
    },
  ]

  // Call the multimodal model, and get a stream of results
  const genAI = new GoogleGenerativeAI(API_KEY)
  const model = genAI.getGenerativeModel({
    model: "gemini-1.5-flash", // or gemini-1.5-pro
    safetySettings: [
      {
        category: HarmCategory.HARM_CATEGORY_HARASSMENT,
        threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH,
      },
    ],
  })

  const result = await model.generateContentStream({ contents })

  // Read from the stream and interpret the output as markdown
  const buffer = []
  for await (const response of result.stream) {
    buffer.push(response.text())
    output.innerHTML = md.render(buffer.join(""))
  }

  // Process the response to enhance the UI
  const responseText = buffer.join("")
  enhanceFirstAidDisplay(responseText)
}

// Enhance the first aid display with UI components
function enhanceFirstAidDisplay(responseText) {
  // Extract injury type and severity
  let injuryType = "Injury Analysis"
  let severity = "Moderate"
  let treatmentTime = "20-30 minutes"

  // Try to extract injury type from the response
  const injuryMatch = responseText.match(
    /(?:burn|cut|fracture|sprain|strain|bleeding|choking|poisoning|heat|stroke|heart attack|concussion|wound)/i,
  )
  if (injuryMatch) {
    injuryType = injuryMatch[0].charAt(0).toUpperCase() + injuryMatch[0].slice(1) + " Injury"
  }

  // Try to extract severity from the response
  const severityMatch = responseText.match(/(?:mild|moderate|severe)/i)
  if (severityMatch) {
    severity = severityMatch[0].charAt(0).toUpperCase() + severityMatch[0].slice(1)
  }

  // Try to extract treatment time from the response
  const timeMatch = responseText.match(/(\d+[-–]\d+\s+minutes|\d+\s+minutes)/i)
  if (timeMatch) {
    treatmentTime = timeMatch[0]
  }

  // Check if emergency warning is present
  const hasEmergency = /(?:emergency|immediate medical attention|call 911|seek medical|hospital)/i.test(responseText)

  // Create enhanced UI
  let enhancedHTML = `
    <div class="first-aid-result">
      <div class="result-header" style="background-color: ${getSeverityColor(severity)}">
        <h3><i class="fas fa-first-aid"></i> ${injuryType}</h3>
        <span class="severity-badge">${severity}</span>
      </div>
  `

  // Add emergency warning if present
  if (hasEmergency) {
    enhancedHTML += `
      <div class="emergency-info">
        <i class="fas fa-exclamation-triangle"></i>
        <p>Immediate medical attention required!</p>
      </div>
    `
  }

  // Add treatment time
  enhancedHTML += `
    <div class="treatment-time">
      <i class="fas fa-clock"></i>
      <p>Estimated treatment time: ${treatmentTime}</p>
    </div>
  `

  // Add the original markdown content
  enhancedHTML += `
    <div class="first-aid-content">
      ${md.render(responseText)}
    </div>
  `

  // Add medical disclaimer
  enhancedHTML += `
    <div class="medical-disclaimer">
      <i class="fas fa-exclamation-circle"></i>
      <div class="disclaimer-content">
        <h4>Medical Disclaimer <span class="important-tag">Important</span></h4>
        <p>This information is not a substitute for professional medical advice, diagnosis, or treatment. Always seek the advice of a qualified healthcare provider with any questions you may have. In case of serious injuries or medical emergencies, call emergency services immediately.</p>
      </div>
    </div>
  `

  enhancedHTML += `</div>`

  // Replace the output content
  output.innerHTML = enhancedHTML

  // Add audio and video buttons to steps
  addMediaButtons()
}

// Get color based on severity
function getSeverityColor(severity) {
  switch (severity.toLowerCase()) {
    case "mild":
      return "#4caf50" // Green
    case "moderate":
      return "#ff9800" // Orange
    case "severe":
      return "#e53935" // Red
    default:
      return "#2d63e9" // Blue (default)
  }
}

// Add audio and video buttons to steps
function addMediaButtons() {
  // Find all list items that might be steps
  const listItems = document.querySelectorAll("ol li, ul li");

  // Only add media buttons to the first list item
  if (listItems.length > 0) {
    const firstItem = listItems[0];

    // Create step actions div
    const stepActions = document.createElement("div");
    stepActions.className = "step-actions";

    // Add watch video button
    const videoButton = document.createElement("button");
    videoButton.className = "step-action-btn";
    videoButton.innerHTML = '<i class="fas fa-video"></i> Watch Video';
    videoButton.addEventListener("click", () => {
      alert("Video demonstration will be available soon!");
    });

    // Add play audio button
    const audioButton = document.createElement("button");
    audioButton.className = "step-action-btn";
    audioButton.innerHTML = '<i class="fas fa-volume-up"></i> Play Audio';
    audioButton.addEventListener("click", () => {
      alert("Audio instructions will be available soon!");
    });

    // Add buttons to step actions
    stepActions.appendChild(videoButton);
    stepActions.appendChild(audioButton);

    // Add step actions to first list item only
    firstItem.appendChild(stepActions);
  }

  // Optionally highlight first step if critical (but without numbering)
  listItems.forEach((item, index) => {
    // Commented this out to remove step numbers:
    // const stepNumber = document.createElement("span");
    // stepNumber.className = "step-number";
    // stepNumber.textContent = index + 1;
    // item.prepend(stepNumber);

    if (index === 0 && /(?:immediately|urgent|critical|emergency)/i.test(item.textContent)) {
      item.classList.add("critical");
    }
  });
}


// You can delete this once you've filled out an API key
maybeShowApiKeyBanner(API_KEY)

