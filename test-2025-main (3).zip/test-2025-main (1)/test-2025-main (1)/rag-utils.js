// RAG (Retrieval-Augmented Generation) Utilities
// This file contains functions for implementing RAG with the Gemini API

import { firstAidKnowledgeBase, knowledgeBaseEmbeddings } from './knowledge-base.js';
import cosineSimilarity from 'compute-cosine-similarity';

/**
 * Simple vector similarity calculation using cosine similarity
 * @param {Array<number>} vec1 - First vector
 * @param {Array<number>} vec2 - Second vector
 * @returns {number} - Similarity score between 0 and 1
 */
export function calculateCosineSimilarity(vec1, vec2) {
  if (vec1.length !== vec2.length) {
    throw new Error('Vectors must have the same dimensions');
  }
  
  // Use the imported cosine similarity function
  const similarity = cosineSimilarity(vec1, vec2);
  
  // Handle NaN cases (when one of the vectors is all zeros)
  return isNaN(similarity) ? 0 : similarity;
}

/**
 * Generate a simple embedding for a query string
 * This is a simplified version for demonstration purposes
 * In a real implementation, you would use a proper embedding model
 * @param {string} query - The query text
 * @returns {Array<number>} - A vector embedding
 */
export function generateSimpleEmbedding(query) {
  // This is a very simplified embedding generation
  // In a real implementation, you would use a proper embedding model
  const keywords = {
    'cut': [0.2, 0.1, 0.8, 0.3, 0.5, 0.2, 0.1, 0.9, 0.3, 0.4],
    'scrape': [0.2, 0.1, 0.8, 0.3, 0.5, 0.2, 0.1, 0.9, 0.3, 0.4],
    'bleed': [0.9, 0.1, 0.3, 0.2, 0.4, 0.8, 0.1, 0.5, 0.3, 0.2],
    'burn': [0.7, 0.2, 0.3, 0.8, 0.1, 0.9, 0.2, 0.3, 0.1, 0.5],
    'sprain': [0.3, 0.8, 0.2, 0.1, 0.7, 0.3, 0.9, 0.2, 0.4, 0.1],
    'strain': [0.3, 0.8, 0.2, 0.1, 0.7, 0.3, 0.9, 0.2, 0.4, 0.1],
    'choke': [0.1, 0.3, 0.5, 0.2, 0.9, 0.1, 0.4, 0.3, 0.7, 0.2],
    'fracture': [0.2, 0.7, 0.1, 0.5, 0.3, 0.2, 0.8, 0.1, 0.4, 0.6],
    'break': [0.2, 0.7, 0.1, 0.5, 0.3, 0.2, 0.8, 0.1, 0.4, 0.6],
    'heart': [0.5, 0.2, 0.4, 0.1, 0.8, 0.3, 0.2, 0.7, 0.1, 0.9],
    'stroke': [0.4, 0.1, 0.7, 0.3, 0.2, 0.5, 0.1, 0.8, 0.3, 0.6],
    'poison': [0.1, 0.5, 0.3, 0.7, 0.2, 0.4, 0.6, 0.1, 0.8, 0.3],
    'heat': [0.6, 0.3, 0.1, 0.4, 0.2, 0.7, 0.3, 0.5, 0.2, 0.8],
  };
  
  // Initialize with zeros
  const embedding = Array(10).fill(0);
  let matchCount = 0;
  
  // Simple keyword matching
  const queryLower = query.toLowerCase();
  for (const [keyword, keywordEmbedding] of Object.entries(keywords)) {
    if (queryLower.includes(keyword)) {
      // Add the keyword embedding to our result
      for (let i = 0; i < embedding.length; i++) {
        embedding[i] += keywordEmbedding[i];
      }
      matchCount++;
    }
  }
  
  // Normalize if we had matches
  if (matchCount > 0) {
    for (let i = 0; i < embedding.length; i++) {
      embedding[i] /= matchCount;
    }
  } else {
    // Default embedding if no keywords matched
    for (let i = 0; i < embedding.length; i++) {
      embedding[i] = Math.random() * 0.5; // Random values but lower magnitude
    }
  }
  
  return embedding;
}

/**
 * Retrieve the most relevant information from the knowledge base
 * @param {string} query - The query text
 * @param {number} topK - Number of results to return
 * @returns {Array<Object>} - Array of relevant knowledge base entries
 */
export function retrieveRelevantInformation(query, topK = 3) {
  // Generate embedding for the query
  const queryEmbedding = generateSimpleEmbedding(query);
  
  // Calculate similarity with each knowledge base entry
  const similarities = Object.entries(knowledgeBaseEmbeddings).map(([id, embedding]) => {
    const similarity = calculateCosineSimilarity(queryEmbedding, embedding);
    return { id, similarity };
  });
  
  // Sort by similarity (descending)
  similarities.sort((a, b) => b.similarity - a.similarity);
  
  // Get top K results
  const topResults = similarities.slice(0, topK);
  
  // Retrieve the full knowledge base entries
  return topResults.map(result => {
    const entry = firstAidKnowledgeBase.find(item => item.id === result.id);
    return {
      ...entry,
      similarity: result.similarity
    };
  });
}

/**
 * Format retrieved information for inclusion in the prompt
 * @param {Array<Object>} retrievedInfo - Array of retrieved knowledge base entries
 * @returns {string} - Formatted context string
 */
export function formatRetrievedInformation(retrievedInfo) {
  if (!retrievedInfo || retrievedInfo.length === 0) {
    return '';
  }
  
  let context = '\n\nHere is some relevant first aid information that might help with your analysis:\n\n';
  
  retrievedInfo.forEach((info, index) => {
    context += `${index + 1}. ${info.title}:\n${info.content}\n\n`;
    if (info.emergency_signs && info.emergency_signs.length > 0) {
      context += `Emergency signs: ${info.emergency_signs.join(', ')}\n\n`;
    }
  });
  
  return context;
}