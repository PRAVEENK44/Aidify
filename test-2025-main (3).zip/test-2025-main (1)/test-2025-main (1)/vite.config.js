// vite.config.js
import { defineConfig } from 'vite'

export default defineConfig({
  build: {
    outDir: 'dist',
    assetsDir: 'assets',
    rollupOptions: {
      external: ['compute-cosine-similarity']
    }
  },
  server: {
    port: 3000
  }
})
